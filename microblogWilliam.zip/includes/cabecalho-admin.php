<?php 
require_once "../src/Services/AutenticacaoServico.php";

/* Se existir/houver um parâmetro de URL chamado 'sair',
execute o método logout. Obs: para o parãmetro existir,
é necessário clicar/acionar o link sair.
*/
if (isset($_GET['sair'])) {
    AutenticacaoServico::logout();
}

?>

<!DOCTYPE html>
<html lang="pt-br" class="h-100">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Microblog</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" sizes="32x32" href="../images/favicon-admin.png">
    <link rel="stylesheet" href="../css/style.css">

</head>

<body id="admin" class="d-flex flex-column h-100 bg-secondary bg-gradient">

    <header id="topo" class="border-bottom sticky-top">

        <nav class="navbar navbar-expand-lg navbar-dark bg-dark justify-content-between">
            <div class="container">
                <h1><a class="navbar-brand" href="index.php"><i class="bi bi-unlock"></i> Admin | Microblog</a></h1>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="meu-perfil.php">Meu perfil</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="noticias.php">Notícias</a>
                        </li>


                       <?php if ($_SESSION['tipo'] == 'admin'): ?>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="usuarios.php">Usuários</a>
                        </li>
                          
                        <?php endif; ?>

                        <li class="nav-item">
                            <a class="nav-link" href="../index.php" target="_blank">Área pública</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link fw-bold"
                            href="?sair"> <i class="bi bi-x-circle"></i> Sair</a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>

    </header>

    <main class="flex-shrink-0">
        <div class="container">

